// compute_fitness.cpp : Defines the entry point for the console application.
//
//#include "stdafx.h"
#include "MyUtils.h"
#include <math.h>
#include <string.h>
//using std::string;

#ifdef N_MAC_OSX_FRAMEWORKS
	#include <NCore/NCore.h>
	#include <NBiometricClient/NBiometricClient.h>
	#include <NBiometrics/NBiometrics.h>
	#include <NMedia/NMedia.h>
	#include <NLicensing/NLicensing.h>
#else
	#include <NCore.h>
	#include <NBiometricClient.h>
	#include <NBiometrics.h>
	#include <NMedia.h>
	#include <NLicensing.h>
	
#endif

//I hate this fuckign code -Milk

const NChar title[] = N_T("CreateSyntheticMasterprint");
const NChar description[] = N_T("Creates Synthetic Masterprint Template from Sampled Masterprint Template by Hill Climbing");
const NChar version[] = N_T("1.0.0.0");
const NChar copyright[] = N_T("");

NFMinutiaFormat minutiaFormat;
/*NUShort Cbeffinfo;
NFRidgeCountsType ridgecountstype;
NUShort verresolution;
NUShort horresolution;
NUShort width;
NUShort height;*/

NInt no_of_minutiae;
HNBiometricClient hBiometricClient = NULL;
FILE *fp = fopen(N_T("fitness_score.csv"), N_T("w+") );
NInt infomatrix[4320];

int usage()
{
	printf(N_T("usage:\n"));
	printf(N_T("\t%s [image] [template] [format]\n"), title);
	printf(N_T("\n"));
	printf(N_T("\t[image]    - image filename to extract.\n"));
	printf(N_T("\t[template] - filename to store extracted features.\n"));
	printf(N_T("\t[format]   - whether proprietary or standard template should be created.\n"));
	printf(N_T("\t\tIf not specified, proprietary Neurotechnology template is created (recommended).\n"));
	printf(N_T("\t\tANSI for ANSI/INCITS 378-2004\n"));
	printf(N_T("\t\tISO for ISO/IEC 19794-2\n"));
	printf(N_T("\n\nexamples:\n"));
	printf(N_T("\t%s image.jpg template.dat\n"), title);
	printf(N_T("\t%s image.jpg isoTemplate.dat ISO\n"), title);

	return 1;
}

NInt RotationToDegrees(NInt rotation)
{
	return (2 * rotation * 360 + 256) / (2 * 256);
}

NInt DegreesToRotation(NInt degree)
{
	return (2 * degree * 256 - 256) / (2 * 360);
} 

const NChar* NFMinutiaTypeToString(NFMinutiaType minutiaType)
{
	switch (minutiaType)
	{
	case nfmtBifurcation:
		return N_T("The minutia that is a bifurcation of a ridge.");
	case nfmtEnd:
		return N_T("The minutia that is an end of a ridge.");
	case nfmtUnknown:
		return N_T("The type of the minutia is unknown.");
	default:
		return N_T("n/a");
	}
}

void PrintNFRecord(HNFRecord hnfRec)
{
	NResult result;
	NUShort ushortVal;
	NByte byteVal;
	NFImpressionType impressionType;
	NFPatternClass patternClass;
	NFPosition position;
	
	NFRidgeCountsType ridgeCountsType;
	NInt featureCount;
	NInt i;
	NSizeType size;
	
	result = NFRecordGetQuality(hnfRec, &byteVal);
	if (NSucceeded(result))
	{
		printf(N_T("\tquality: %d\n"), byteVal);
	}

	result = NObjectGetSize(hnfRec, 0, &size);
	if (NSucceeded(result))
	{
		printf(N_T("\tsize: %ld\n"), (unsigned long)size);
	}

	result = NFRecordGetMinutiaFormat(hnfRec, &minutiaFormat);
	if (NSucceeded(result))
	{
		printf(N_T("\t minutiaFormat: %d\n"), minutiaFormat);
	}
	/*result = NFRecordGetCbeffProductType(hnfRec, &Cbeffinfo);

	result = NFRecordGetRidgeCountsType(hnfRec, &ridgecountstype);

	result = NFRecordGetWidth(hnfRec, &width);
	if (NSucceeded(result))
	{
		printf(N_T("\twidth: %d\n"), width);
	}

	result = NFRecordGetHeight(hnfRec, &height);
	if (NSucceeded(result))
	{
		printf(N_T("\theight: %d\n"), height);
	}

	result = NFRecordGetHorzResolution(hnfRec, &horresolution);
	if (NSucceeded(result))
	{
		printf(N_T("\thorizontal resolution: %d\n"), horresolution);
	}

	result = NFRecordGetVertResolution(hnfRec, &verresolution);
	if (NSucceeded(result))
	{
		printf(N_T("\tvertical resolution: %d\n"), verresolution);
	}*/

	/* minutiae */
	result = NFRecordGetMinutiaCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFMinutia minutia;

		printf(N_T("\tminutia count: %d\n"), featureCount);

		no_of_minutiae = featureCount;

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetMinutia(hnfRec, i, &minutia);
			if (NSucceeded(result))
			{
				printf(N_T("\tminutia %d of %d:\t"), i+1, featureCount);
				printf(N_T("\tx: %d \t"), minutia.X);
				printf(N_T("\ty: %d \t"), minutia.Y);
				printf(N_T("\tangle: %d\t"), RotationToDegrees(minutia.Angle));
				//printf(N_T("\t\ttype: %s\n"), NFMinutiaTypeToString(minutia.Type));
				fprintf(fp,N_T("%d, "), minutia.X);
				fprintf(fp,N_T("%d, "), minutia.Y);
				fprintf(fp,N_T("%d, "), RotationToDegrees(minutia.Angle));

				if (minutiaFormat & nfmfHasQuality)
				{
					printf(N_T("\tquality: %d\t"), minutia.Quality);					
				}
				if (minutiaFormat & nfmfHasG)
				{
					printf(N_T("\tg: %d\t"), minutia.G);
				}
				if (minutiaFormat & nfmfHasCurvature)
				{
					printf(N_T("\tcurvature: %d\n"), minutia.Curvature);
				}
				printf(N_T("\n"));
			}
			
		}
	}

	/* deltas */
	result = NFRecordGetDeltaCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFDelta delta;

		printf(N_T("\tdelta count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetDelta(hnfRec, i, &delta);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tdelta %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), delta.X);
				printf(N_T("\t\ty: %d\n"), delta.Y);
				printf(N_T("\t\tangle1: %d\n"), RotationToDegrees(delta.Angle1));
				printf(N_T("\t\tangle2: %d\n"), RotationToDegrees(delta.Angle2));
				printf(N_T("\t\tangle3: %d\n"), RotationToDegrees(delta.Angle3));
			}
		}
	}

	/* cores */
	result = NFRecordGetCoreCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFCore core;

		printf(N_T("\tcore count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetCore(hnfRec, i, &core);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tcore %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), core.X);
				printf(N_T("\t\ty: %d\n"), core.Y);
				printf(N_T("\t\tangle: %d\n"), RotationToDegrees(core.Angle));
			}

		}
	}
	

	/* double cores */
	result = NFRecordGetDoubleCoreCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFDoubleCore doubleCore;

		printf(N_T("\tdouble core count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetDoubleCore(hnfRec, i, &doubleCore);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tdouble core %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), doubleCore.X);
				printf(N_T("\t\ty: %d\n"), doubleCore.Y);
			}
		}
	}
}

NResult PrintNFTemplate(HNTemplate hnTemplate)
{
	NResult result = N_OK;
	HNFTemplate hnfTemplate = NULL;
	NInt i;
	NInt recordCount;

	result = NTemplateGetFingersEx(hnTemplate, &hnfTemplate);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NTemplateGetFingers, error code: %d"), result);
			return result;
		}

	if (hnfTemplate)
	{
		HNFRecord hnfRec;

		result = NFTemplateGetRecordCount(hnfTemplate, &recordCount);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NFTemplateGetRecordCount, error code: %d"), result);
//			result = NObjectSet(NULL, &hnfTemplate);
			hnfTemplate = NULL;
			result = N_E_FAILED;
			return result;
		}
		printf(N_T("%d finger records\n"), recordCount);
		
		for (i = 0; i < recordCount; i++)
		{
			result = NFTemplateGetRecordEx(hnfTemplate, i, &hnfRec);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("error in NFTemplateGetRecord, error code: %d"), result);
//				result = NObjectSet(NULL, &hnfTemplate);
				hnfTemplate = NULL;
				result = N_E_FAILED;
				return result;
			}

			PrintNFRecord(hnfRec);

//			result = NObjectSet(NULL, &hnfRec);
			hnfRec = NULL;
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NObjectSet() failed (result = %d)!"), result);
				return result;
			}
		}
//		result = NObjectSet(NULL, &hnfTemplate);
		hnfTemplate = NULL;
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSet() failed (result = %d)!"), result);
			return result;
		}
	}
	else
		printf(N_T("0 finger records\n"));
	
	return result;
}

NResult CreateSubject(HNSubject hSubject, const NChar * fileName)
{
	HNBuffer hBuffer = NULL;
	NResult result = N_OK;

	// read template
	result = NFileReadAllBytesCN(fileName, &hBuffer);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NFileReadAllBytesCN() failed (result = %d)!"), result);
		goto FINALLY;
	}

	// set template for subject
	result = NSubjectSetTemplateBuffer(hSubject, hBuffer);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NSubjectSetTemplateBuffer() failed (result = %d)!"), result);
		goto FINALLY;
	}

	// set id for the subject
	result = NSubjectSetId(hSubject, fileName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NSubjectSetId() failed (result = %d)!"), result);
		goto FINALLY;
	}

FINALLY:
	{
		NResult result2 = NBufferGetEmpty(&hBuffer);
		if (NFailed(result2)) PrintErrorMsg(N_T("NBufferGetEmpty() failed (result = %d)!"), result2);
	}

	return result;
}


NResult Initialize(NInt threshold)
{

	// create biometric client
	NResult result = N_OK;
	const NChar * components = { N_T("Biometrics.FingerExtraction,Biometrics.FingerMatching") };
	NBool available = NFalse;
	
	// check the license first
	result = NLicenseObtainComponents(N_T("/local"), N_T("5000"), components, &available);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NLicenseObtainComponents() failed (result = %d)!"), result);
		return result;
	}

	if (!available)
	{
		printf(N_T("Licenses for %s not available\n"), components);
		result = N_E_NOT_ACTIVATED;
		return result;
	}

	result = NBiometricClientCreate(&hBiometricClient);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NBiometricClientCreate() failed (result = %d)!"), result);
		return result;
	}

	{
        //Philip: Thresholds: 1, .1, .01 : 35, 50, 65
		NInt matchingThreshold = threshold;
		NInt minimumMinutiae = 1;
		NTemplateSize templateSize =  ntsLarge;
		NMatchingSpeed matchingSpeed = nmsLow;
		NInt minutiaeQuality = 1;	
		// set matching threshold
		result = NObjectSetPropertyP(hBiometricClient, N_T("Matching.Threshold"), N_TYPE_OF(NInt32), naNone, &matchingThreshold, sizeof(matchingThreshold), 1, NTrue);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSetPropertyP() failed (result = %d)!"), result);
			return result;
		}
		// set matching speed
		result = NObjectSetPropertyP(hBiometricClient, N_T("Fingers.MatchingSpeed"), N_TYPE_OF(NMatchingSpeed), naNone, &matchingSpeed, sizeof(matchingSpeed), 1, NTrue);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSetPropertyP() failed (result = %d)!"), result);
			return result;
		}
		
	}

	
}


int compute_false_match_count_from_random_minutiae(const NChar * p_templateFileName, HNTemplate hProbeTemplate, NInt p_subject_no, const NChar * dataset)
{
	HNSubject hProbeSubject = NULL;
	HNSubject hGallerySubject = NULL;	
	HNMatchingResult hMatchingResults = NULL;
	HNString hBiometricStatus = NULL;
	NResult result = N_OK;
	NBiometricStatus biometricStatus = nbsNone;
	NInt matchScore = 0;
	const NChar * szBiometricStatus = NULL;
	NInt match_count = 0;
	NInt subject_matched_ary[720] = {0};
	NInt SubMatchCount = 0;
	NInt subject_match_count = 0;

	
	//printf(N_T("create subject for probe image \n"));
	// create subject for probe image
	result = NSubjectCreate(&hProbeSubject);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("Here NSubjectCreate() failed (result = %d)!"), result);
		goto FINALLY;
	}
	//printf(N_T("create biometric client \n"));
	
	
	//printf(N_T("set template for subject \n"));
	// set template for subject
	result = NSubjectSetTemplate(hProbeSubject, hProbeTemplate);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NSubjectSetTemplate() failed (result = %d)!"), result);
		goto FINALLY;
	}

	// set id for the subject
	result = NSubjectSetId(hProbeSubject, p_templateFileName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NSubjectSetId() failed (result = %d)!"), result);
		goto FINALLY;
	}

	//printf(N_T("p_templateFileName = %s\n"), p_templateFileName);					
	
	//use all of them
	for (NInt loop_i = 0; loop_i < 8640; loop_i++) {
			NInt g_i = loop_i+1;
			//printf(N_T("G_i = %d \t"), g_i);    
			NInt subject_match_flag = 0;
			//Philip: Capacitive Data
			//NChar *g_s1 = N_T("/home/jupyter/Notebooks/philip/MasterPrint/Verifinger/DB7AuthentecCapacitivePress/");

  			NInt g_subject_no = (g_i-1)/12 + 1;
			NInt g_fingerprint_no = (g_i - 1)%12 + 1;
        
        
            //skip a user if already matched
            if(subject_matched_ary[g_subject_no-1]==1){
                continue;
            }
            //otherwise evaluate
			else if(g_subject_no != p_subject_no ){
		
				NChar g_count_str1 [100] = {};
				sprintf(g_count_str1, N_T("%d"), g_subject_no);
				NChar g_count_str2 [100];
				sprintf(g_count_str2, N_T("%d"), g_fingerprint_no);
			    
				NChar g_inFileName [1000];
				strcpy (g_inFileName, dataset);
				strcat (g_inFileName, N_T("AES3400_0"));
				if(g_subject_no<10)
					strcat (g_inFileName, N_T("00"));
				else if (g_subject_no>=10 && g_subject_no<100)
					strcat (g_inFileName, N_T("0"));
				else if (g_subject_no>=100 && g_subject_no<=720)
					strcat (g_inFileName, N_T(""));

				strcat (g_inFileName, g_count_str1);
				strcat (g_inFileName, N_T("_"));
				if(g_fingerprint_no<10)
					strcat (g_inFileName, N_T("0"));
			
				strcat (g_inFileName, g_count_str2);
				strcat (g_inFileName,  N_T(".BMP"));
				strcat (g_inFileName,  N_T("_feature.dat"));
				//printf(N_T("g_inFileName = %s\n"), g_inFileName);

				hGallerySubject = NULL;
								
				// create subject for gallery image
				result = NSubjectCreate(&hGallerySubject);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("NSubjectCreate() failed (result = %d)!"), result);
					goto FINALLY;
				}
				result = CreateSubject(hGallerySubject, g_inFileName);
				if (NFailed(result))
				{
					PrintErrorMsg(N_T("CreateSubject() failed (result = %d)!"), result);
					//goto FINALLY;
					//fprintf(fp,N_T("%d, "), -1);
					goto NextFile;
				}
					
				// verify probe and gallery templates
				result = NBiometricEngineVerifyOffline(hBiometricClient, hProbeSubject, hGallerySubject, &biometricStatus);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("NBiometricEngineVerifyOffline() failed (result = %d)!"), result);
					//fprintf(fp,N_T("%d, "), -1);
					goto NextFile;
				}

				if (biometricStatus != nbsOk)
				{
					// retrieve biometric status
					result = NEnumToStringP(N_TYPE_OF(NBiometricStatus), biometricStatus, NULL, &hBiometricStatus);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NEnumToStringP() failed (result = %d)!"), result); 							
						goto FINALLY;
					}
			
					result = NStringGetBuffer(hBiometricStatus, NULL, &szBiometricStatus);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result); 							
						goto FINALLY;
					}
				
					//printf(N_T("verification failed!\n"));
					//printf(N_T("biometric status: %s\n"), szBiometricStatus);
					// retrieve matching results from hProbeSubject
					result = NSubjectGetMatchingResult(hProbeSubject, 0, &hMatchingResults);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result); 
						//fprintf(fp,N_T("%d, "), -1);//goto FINALLY;
					}

					// retrieve matching score from matching results
					result = NMatchingResultGetScore(hMatchingResults, &matchScore);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result);
						//goto FINALLY;
					}
					//fprintf(fp,N_T("score = %d, "), matchScore);
					//printf(N_T("\nimage scored %d, verification.. FAILED\n"), matchScore);
				}
				else
				{
					// retrieve matching results from hProbeSubject
					result = NSubjectGetMatchingResult(hProbeSubject, 0, &hMatchingResults);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result);
						goto FINALLY;
					}
					// retrieve matching score from matching results
					result = NMatchingResultGetScore(hMatchingResults, &matchScore);
					if (NFailed(result))
					{
						result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result);
						goto FINALLY;
					}
			
					//match_count = match_count + 1;
					//printf(N_T("G_i = %d, total count = %d\t"), g_i, match_count);	
					//printf(N_T("image scored %d, verification.. Succeed\n"), matchScore);
					subject_match_flag = 1;
					//fprintf(fp,N_T("%d, "),matchScore);
				}// end if else		
				
				NextFile: printf(N_T(""));
				
				//fprintf(fp,N_T("%d, "), subject_match_flag);
				//fprintf(fpointer,N_T("%d, "), subject_match_flag);
				
                //just check if the subject was matched at all and return the subject number
				if( subject_match_flag == 1 ){
					subject_match_count = subject_match_count + 1;
				    subject_matched_ary[g_subject_no-1] = 1;
					//printf(N_T("Image Number = %d, Subject Number = %d, Match Score = %d, Total Match Count = %d, \n"), g_i, g_subject_no, matchScore, subject_match_count);
					//printf(N_T("%d,%d,%d,%d;"), g_i, g_subject_no, matchScore, subject_match_count);
                    printf(N_T("%d;"), g_subject_no);
			    }
				//FUCK THIS CODE!!!!!!
			}//end if
			
	}// end gallery count for
	//printf(N_T("total count = %d\t"), match_count);
	//printf(N_T("Subject Match Count = %d \n"), subject_match_count);	
	//fprintf(fp,N_T("%d \n"), match_count);	
	//fprintf(fp,N_T("%d \n"), subject_match_count);	
	for (NInt i = 0; i<720; i++)
	{
		if(subject_matched_ary[i] == 1){
			SubMatchCount = SubMatchCount + 1;
		}
	}
	//printf(N_T("Total Count = %d, Subject Match Count = %d \n"), match_count, SubMatchCount);	
	
	//fprintf(fpointer,N_T("\n"));
	//fclose(fp);
	//fclose(fpointer);

	result = N_OK;		
FINALLY:
	{
		NResult result2;
		
		hProbeSubject = NULL;
		hGallerySubject = NULL;
		result2 = NBiometricClientCancel(hBiometricClient);
		if (NFailed(result2)) PrintErrorMsg(N_T("NBiometricClientCancel() failed (result = %d)!"), result2);
		//result2 = NObjectSet(NULL, &hMatchingResults);
		//if (NFailed(result2)) PrintErrorMsg(N_T("NObjectUnrefArray() failed (result = %d)!"), result2);
		result2 = NStringSet(NULL, &hBiometricStatus);
		if (NFailed(result2)) PrintErrorMsg(N_T("NStringSet() failed (result = %d)!"), result);
		
	}
	
return SubMatchCount;//result;
}

int main(int argc, NChar** argv)
{
	//CompImposterMatch cim;
	NResult result = N_OK;

	NChar *dataset = N_T(argv[1]);
	NInt threshold = atoi(argv[3]);
	
	//OnStart(title, description, version, copyright, argc, argv);
	Initialize(threshold);

	HNBuffer bestBuffer = NULL;
	HNTemplate bestTemplate = NULL;

	NInt fitness = 0;
	NInt name_ary[140][2];
    //Philip: Put file name here
	NChar *p_s1 = N_T(argv[2]);
  	NChar p_inFileName [1000];
	strcpy (p_inFileName, p_s1);
	//printf(N_T("p_inFileName = %s\n"), p_inFileName);

		bestBuffer = NULL;
		bestTemplate = NULL;

		result = NFileReadAllBytesCN(p_inFileName, &bestBuffer);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NFileReadAllBytesCN, error code: %d"), result);
			//goto FINALLY;
		}

		//result = NTemplateCreateFromMemoryN(bestBuffer, NFR_SKIP_GS | NFR_SKIP_CURVATURES | NFR_SKIP_QUALITIES, NULL, &bestTemplate);
		result = NTemplateCreateFromMemoryN(bestBuffer, 0, NULL, &bestTemplate);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NTemplateCreateFromMemory, error code: %d"), result);
			//goto FINALLY;
		}	

		//printf(N_T("template contains:\n"));
		
		//fprintf(fp,N_T("\n "));
		
		//result = PrintNFTemplate(bestTemplate);
		//if (NFailed(result))
		//{
		//	result = PrintErrorMsgWithLastError(N_T("error in PrintNFTemplate(), error code: %d"), result); 			
		//	//goto FINALLY;
		//}

		fitness = compute_false_match_count_from_random_minutiae(N_T("Template"), bestTemplate, 0, dataset);
		//fprintf(fp,N_T("%d "), fitness);
	
	//fclose(fp);

	result = N_OK;
	FINALLY:
	{
		NResult result2 = NBufferGetEmpty(&bestBuffer);
		if (NFailed(result2)) PrintErrorMsg(N_T("NBufferGetEmpty() failed (result = %d)!"), result2);
		//result2 = NObjectSet(NULL, &hTemplate);
		//if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
		fclose(fp);
	}

	OnExit();
 
	
	
	
	return 0;
}
