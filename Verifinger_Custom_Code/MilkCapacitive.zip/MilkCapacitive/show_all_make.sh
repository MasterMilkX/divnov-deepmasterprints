#!/bin/bash
echo 'make SHELL="/bin/bash -x" target'
