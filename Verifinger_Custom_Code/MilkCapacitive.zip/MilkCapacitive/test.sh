#!/bin/bash
./MasterPrintMatchImageCapacitive /home/jupyter/Notebooks/Milk/DeepPrint2/Verifinger_SDK_Code/Verifinger_SDK/DB7AuthentecCapacitivePress/ ~/Notebooks/Milk/DeepPrint2/Verifinger_SDK_Code/spoof_print_temp.png_featurelarge.dat 50

