// my_finger_verifier.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include "MyUtils.h"// my_enroll_finger.cpp : Defines the entry point for the console application.
//#include <wchar.h>
#include <ctype.h>

#ifdef N_MAC_OSX_FRAMEWORKS
	#include <NCore/NCore.h>
	#include <NBiometricClient/NBiometricClient.h>
	#include <NBiometrics/NBiometrics.h>
	#include <NMedia/NMedia.h>
	#include <NLicensing/NLicensing.h>
#else
	#include <NCore.h>
	#include <NBiometricClient.h>
	#include <NBiometrics.h>
	#include <NMedia.h>
	#include <NLicensing.h>
#endif



const NChar title[] = N_T("EnrollFingerFromImage");
const NChar description[] = N_T("Demonstrates fingerprint feature extraction from image.");
const NChar version[] = N_T("6.0.0.0");
const NChar copyright[] = N_T("Copyright (C) 2008-2015 Neurotechnology");

int usage()
{
	printf(N_T("usage:\n"));
	printf(N_T("\t%s [image] [template] [format]\n"), title);
	printf(N_T("\n"));
	printf(N_T("\t[image]    - image filename to extract.\n"));
	printf(N_T("\t[template] - filename to store extracted features.\n"));
	printf(N_T("\t[format]   - whether proprietary or standard template should be created.\n"));
	printf(N_T("\t\tIf not specified, proprietary Neurotechnology template is created (recommended).\n"));
	printf(N_T("\t\tANSI for ANSI/INCITS 378-2004\n"));
	printf(N_T("\t\tISO for ISO/IEC 19794-2\n"));
	printf(N_T("\n\nexamples:\n"));
	printf(N_T("\t%s image.jpg template.dat\n"), title);
	printf(N_T("\t%s image.jpg isoTemplate.dat ISO\n"), title);

	return 1;
}

NInt RotationToDegrees(NInt rotation)
{
	return (2 * rotation * 360 + 256) / (2 * 256);
}

void PrintNFRecord(HNFRecord hnfRec)
{
	NResult result;
	NUShort ushortVal;
	NByte byteVal;
	NFImpressionType impressionType;
	NFPatternClass patternClass;
	NFPosition position;
	NFMinutiaFormat minutiaFormat;
	NFRidgeCountsType ridgeCountsType;
	NInt featureCount;
	NInt i;
	NSizeType size;
	
	result = NFRecordGetQuality(hnfRec, &byteVal);
	if (NSucceeded(result))
	{
		printf(N_T("\tquality: %d\n"), byteVal);
	}

	result = NObjectGetSize(hnfRec, 0, &size);
	if (NSucceeded(result))
	{
		printf(N_T("\tsize: %ld\n"), (unsigned long)size);
	}

	result = NFRecordGetMinutiaFormat(hnfRec, &minutiaFormat);

	/* minutiae */
	result = NFRecordGetMinutiaCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFMinutia minutia;

		printf(N_T("\tminutia count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetMinutia(hnfRec, i, &minutia);
			if (NSucceeded(result))
			{
				printf(N_T("\tminutia %d of %d:\t"), i+1, featureCount);
				printf(N_T("\tx: %d \t"), minutia.X);
				printf(N_T("\ty: %d \t"), minutia.Y);
				printf(N_T("\tangle: %d\t"), RotationToDegrees(minutia.Angle));
				//printf(N_T("\t\ttype: %s\n"), NFMinutiaTypeToString(minutia.Type));
				if (minutiaFormat & nfmfHasQuality)
				{
					printf(N_T("\tquality: %d\t"), minutia.Quality);
				}
				if (minutiaFormat & nfmfHasG)
				{
					printf(N_T("\tg: %d\t"), minutia.G);
				}
				if (minutiaFormat & nfmfHasCurvature)
				{
					printf(N_T("\tcurvature: %d\n"), minutia.Curvature);
				}
				printf(N_T("\n"));
			}
		}
	}

	/* deltas */
	result = NFRecordGetDeltaCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFDelta delta;

		printf(N_T("\tdelta count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetDelta(hnfRec, i, &delta);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tdelta %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), delta.X);
				printf(N_T("\t\ty: %d\n"), delta.Y);
				printf(N_T("\t\tangle1: %d\n"), RotationToDegrees(delta.Angle1));
				printf(N_T("\t\tangle2: %d\n"), RotationToDegrees(delta.Angle2));
				printf(N_T("\t\tangle3: %d\n"), RotationToDegrees(delta.Angle3));
			}
		}
	}

	/* cores */
	result = NFRecordGetCoreCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFCore core;

		printf(N_T("\tcore count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetCore(hnfRec, i, &core);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tcore %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), core.X);
				printf(N_T("\t\ty: %d\n"), core.Y);
				printf(N_T("\t\tangle: %d\n"), RotationToDegrees(core.Angle));
			}
		}
	}

	/* double cores */
	result = NFRecordGetDoubleCoreCount(hnfRec, &featureCount);
	if (NSucceeded(result))
	{
		NFDoubleCore doubleCore;

		printf(N_T("\tdouble core count: %d\n"), featureCount);

		for (i = 0; i < featureCount; i++)
		{
			result = NFRecordGetDoubleCore(hnfRec, i, &doubleCore);
			if (NSucceeded(result))
			{
				printf(N_T("\t\tdouble core %d of %d:\n"), i+1, featureCount);
				printf(N_T("\t\tx: %d\n"), doubleCore.X);
				printf(N_T("\t\ty: %d\n"), doubleCore.Y);
			}
		}
	}
}

NResult PrintNFTemplate(HNTemplate hnTemplate)
{
	NResult result = N_OK;
	HNFTemplate hnfTemplate = NULL;
	NInt i;
	NInt recordCount;

	result = NTemplateGetFingersEx(hnTemplate, &hnfTemplate);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NTemplateGetFingers, error code: %d"), result);
			return result;
		}

	if (hnfTemplate)
	{
		HNFRecord hnfRec;

		result = NFTemplateGetRecordCount(hnfTemplate, &recordCount);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("error in NFTemplateGetRecordCount, error code: %d"), result);
//			result = NObjectSet(NULL, &hnfTemplate);
			result = N_E_FAILED;
			return result;
		}
		printf(N_T("%d finger records\n"), recordCount);
		
		for (i = 0; i < recordCount; i++)
		{
			result = NFTemplateGetRecordEx(hnfTemplate, i, &hnfRec);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("error in NFTemplateGetRecord, error code: %d"), result);
//				result = NObjectSet(NULL, &hnfTemplate);
				result = N_E_FAILED;
				return result;
			}

			PrintNFRecord(hnfRec);

//			result = NObjectSet(NULL, &hnfRec);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NObjectSet() failed (result = %d)!"), result);
				return result;
			}
		}
//		result = NObjectSet(NULL, &hnfTemplate);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSet() failed (result = %d)!"), result);
			return result;
		}
	}
	else
		printf(N_T("0 finger records\n"));
	
	return result;
}


NResult CreateAndUpdateImage(HNImage hImage, const NChar * fileName)
{
	// read and set the image for the finger
	HNImageFormat hSrcImageFormat = NULL;
	HNImageFormat hImageFormat = NULL;
	HNImageInfo hImageInfo = NULL;
	HNString hName = NULL;
	//	NBool available = NFalse;
	NBool areSame = NFalse;
	NUInt widthVal = NULL;
	NUInt heightVal = NULL;
	NFloat hresVal = NULL;
	NFloat vresVal = NULL;
	NResult result = N_OK;
	
	// create NImage with info from file
	result = NImageCreateFromFileEx(fileName, NULL, 0, NULL, &hImage);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageCreateFromFileEx() failed, result = %d\n"), result);
		goto FINALLY;
	}

	
	result = NImageGetWidth(hImage, &widthVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetWidth() failed, result = %d\n"), result);
		goto FINALLY;
	}
	else
	{
		printf(N_T("Image Width: %d\n"), widthVal);
	}

	result = NImageGetHeight(hImage, &heightVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetHeight() failed, result = %d\n"), result);
		goto FINALLY;
	}
	else
	{
		printf(N_T("Image Height: %d\n"), heightVal);
	}

	result = NImageGetHorzResolution(hImage, &hresVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetHorzResolution() failed, result = %d\n"), result);
		goto FINALLY;
	}
	else
	{
		printf(N_T("Image Horizontal Resolution: %lf\n"), hresVal);
		if(vresVal == 0){
			result = NImageSetHorzResolution(hImage, 500);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NImageSetHorzResolution() failed, result = %d\n"), result);
				goto FINALLY;
			}
		}
		result = NImageGetHorzResolution(hImage, &hresVal);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NImageGetHorzResolution() failed, result = %d\n"), result);
			goto FINALLY;
		}
		else	
			printf(N_T("Image Horizontal Resolution: %lf\n"), hresVal);
	}

	result = NImageGetVertResolution(hImage, &vresVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetVertResolution() failed, result = %d\n"), result);
		goto FINALLY;
	}
	else
	{
		printf(N_T("Image Vertical Resolution: %lf\n"), vresVal);
		if(vresVal == 0)
		{
			result = NImageSetVertResolution(hImage, 500);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NImageSetVertResolution() failed, result = %d\n"), result);
				goto FINALLY;
			}
		}
		result = NImageGetVertResolution(hImage, &vresVal);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NImageGetVertResolution() failed, result = %d\n"), result);
			goto FINALLY;
		}
		else
			printf(N_T("Image Vertical Resolution: %lf\n"), vresVal);
	}


	result = NImageGetInfo(hImage, &hImageInfo);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetInfo() failed, result = %d\n"), result);
		goto FINALLY;
	}

	// get image format
	result = NImageInfoGetFormatEx(hImageInfo, &hSrcImageFormat);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageInfoGetFormatEx() failed, result = %d\n"), result);
		goto FINALLY;
	}

	// print info common to all formats
	result = NImageFormatGetNameN(hSrcImageFormat, &hName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageFormatGetNameN() failed, result = %d\n"), result);
		goto FINALLY;
	}
	{
		const NChar * szName;
		result = NStringGetBuffer(hName, NULL, &szName);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed, result = %d\n"), result);
			goto FINALLY;
		}
		//printf(N_T("format: %s\n"), szName);
	}
	result = NStringSet(NULL, &hName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("failed to clear name (result = %d)!\n"), result);
		goto FINALLY;
	}
	result = N_OK;
	FINALLY:
		{
			//printf(N_T("FUNCTION FINALLY\n"));
			//		NResult result2 = NObjectSet(NULL, &hFinger);
			//		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
		}

	return result;
}

NChar *trim(NChar *str)
{
    size_t len = 0;
    NChar *frontp = str;
    NChar *endp = NULL;

    if( str == NULL ) { return NULL; }
    if( str[0] == '\0' ) { return str; }

    len = strlen(str);
    endp = str + len;

    /* Move the front and back pointers to address the first non-whitespace
     * characters from each end.
     */
    while( isspace(*frontp) ) { ++frontp; }
    if( endp != frontp )
    {
        while( isspace(*(--endp)) && endp != frontp ) {}
    }

    if( str + len - 1 != endp )
            *(endp + 1) = '\0';
    else if( frontp != str &&  endp == frontp )
            *str = '\0';

    /* Shift the string so that it starts at str so that if it's dynamically
     * allocated, we can still free it on the returned pointer.  Note the reuse
     * of endp to mean the front of the string buffer now.
     */
    endp = str;
    if( frontp != str )
    {
            while( *frontp ) { *endp++ = *frontp++; }
            *endp = '\0';
    }


    return str;
}

NResult CreateSubject(HNSubject hSubject, const NChar * fileName)
{
	HNFinger hFinger = NULL;
	NResult result = N_OK;

	// create finger for the subject
	result = NFingerCreate(&hFinger);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NFingerCreate() failed (result = %d)!"), result);
		return result;
	}

	// read and set the image for the finger
	// read and set the image for the finger
	
	HNImage hImage = NULL;
	HNImageFormat hSrcImageFormat = NULL;
	HNImageFormat hImageFormat = NULL;
	HNImageInfo hImageInfo = NULL;
	HNString hName = NULL;
//	NBool available = NFalse;
	NBool areSame = NFalse;
	NUInt widthVal = NULL;
	NUInt heightVal = NULL;
	NFloat hresVal = NULL;
	NFloat vresVal = NULL;

	
	// create NImage with info from file
	result = NImageCreateFromFileEx(fileName, NULL, 0, NULL, &hImage);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageCreateFromFileEx() failed, result = %d\n"), result);
		return result;
	}

	
	result = NImageGetWidth(hImage, &widthVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetWidth() failed, result = %d\n"), result);
		return result;
	}
	else
	{
		printf(N_T("Image Width: %d\n"), widthVal);
	}

	result = NImageGetHeight(hImage, &heightVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetHeight() failed, result = %d\n"), result);
		return result;
	}
	else
	{
		printf(N_T("Image Height: %d\n"), heightVal);
	}

	result = NImageGetHorzResolution(hImage, &hresVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetHorzResolution() failed, result = %d\n"), result);
		return result;
	}
	else
	{
		printf(N_T("Image Horizontal Resolution: %lf\n"), hresVal);
		if(vresVal < 500){
			result = NImageSetHorzResolution(hImage, 500);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NImageSetHorzResolution() failed, result = %d\n"), result);
				return result;
			}
		}
		result = NImageGetHorzResolution(hImage, &hresVal);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NImageGetHorzResolution() failed, result = %d\n"), result);
			return result;
		}
		else{	
			printf(N_T("Image Horizontal Resolution: %lf\n"), hresVal);
		}
	}

	result = NImageGetVertResolution(hImage, &vresVal);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetVertResolution() failed, result = %d\n"), result);
		return result;
	}
	else
	{
		printf(N_T("Image Vertical Resolution: %lf\n"), vresVal);
		if(vresVal <500)
		{
			result = NImageSetVertResolution(hImage, 500);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NImageSetVertResolution() failed, result = %d\n"), result);
				return result;
			}
		}
		result = NImageGetVertResolution(hImage, &vresVal);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NImageGetVertResolution() failed, result = %d\n"), result);
			return result;
		}
		else{
			printf(N_T("Image Vertical Resolution: %lf\n"), vresVal);
		}
	}


	result = NImageGetInfo(hImage, &hImageInfo);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageGetInfo() failed, result = %d\n"), result);
		return result;
	}

	// get image format
	result = NImageInfoGetFormatEx(hImageInfo, &hSrcImageFormat);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageInfoGetFormatEx() failed, result = %d\n"), result);
		return result;
	}

	// print info common to all formats
	result = NImageFormatGetNameN(hSrcImageFormat, &hName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NImageFormatGetNameN() failed, result = %d\n"), result);
		return result;
	}
	{
		const NChar * szName;
		result = NStringGetBuffer(hName, NULL, &szName);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed, result = %d\n"), result);
			return result;
		}
		//printf(N_T("format: %s\n"), szName);
	}
	result = NStringSet(NULL, &hName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("failed to clear name (result = %d)!\n"), result);
		return result;
	}

	result = NBiometricSetFileName(hFinger, fileName);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NBiometricSetFileNameN() failed (result = %d)!"), result);
		return result;
	}

	result =  NFrictionRidgeSetImage(hFinger, hImage);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NFrictionRidgeSetImage() failed (result = %d)!"), result);
		return result;
	}

	// set the finger for the subject
	result = NSubjectAddFinger(hSubject, hFinger, NULL);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NSubjectAddFinger() failed (result = %d)!"), result);
		return result;
	}
	result = N_OK;
FINALLY:
	{

		//printf(N_T("FUNCTION FINALLY\n"));
//		NResult result2 = NObjectSet(NULL, &hFinger);
//		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
	}

	return result;
}

int main(int argc, NChar **argv)
{
	HNBiometricClient hBiometricClient = NULL;
	HNString hBiometricStatus = NULL;
	NResult result = N_OK;
	const NChar * components = { N_T("Biometrics.FingerExtraction") };
	NBool available = NFalse;
	NBiometricStatus biometricStatus = nbsNone;
	const NChar * szBiometricStatus = NULL;
	BdifStandard standard = bsUnspecified;
		
	OnStart(title, description, version, copyright, argc, argv);
	// check the license first
	result = NLicenseObtainComponents(N_T("/local"), N_T("5000"), components, &available);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NLicenseObtainComponents() failed (result = %d)!"), result);
		goto FINALLY;
	}

	if (!available)
	{
		printf(N_T("Licenses for %s not available\n"), components);
		result = N_E_NOT_ACTIVATED;
		goto FINALLY;
	}

	// create biometric client
	result = NBiometricClientCreate(&hBiometricClient);
	if (NFailed(result))
	{
		result = PrintErrorMsgWithLastError(N_T("NBiometricClientCreate() failed (result = %d)!"), result);
		goto FINALLY;
	}

	NInt p_i, p_subject_no, p_fingerprint_no;
	{
		NInt minimumMinutiae = 1;
		NTemplateSize templateSize = ntsLarge;
		NInt minutiaeQuality = 1;	
		result = NObjectSetPropertyP(hBiometricClient, N_T("Fingers.MinimalMinutiaCount"), N_TYPE_OF(NInt32), naNone, &minimumMinutiae, sizeof(minimumMinutiae), 1, NTrue);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSetPropertyP() failed (result = %d)!"), result);
			goto FINALLY;
		}

		// set template size to small
		result = NObjectSetPropertyP(hBiometricClient, N_T("Fingers.TemplateSize"), N_TYPE_OF(NTemplateSize), naNone, &templateSize, sizeof(templateSize), 1, NTrue);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSetProperty() failed (result = %d)!"), result);
			goto FINALLY;
		}

		result = NObjectSetPropertyP(hBiometricClient, N_T("Fingers.QualityThreshold"), N_TYPE_OF(NInt32), naNone, &minutiaeQuality, sizeof(minutiaeQuality), 1, NTrue);
		if (NFailed(result))
		{
			result = PrintErrorMsgWithLastError(N_T("NObjectSetProperty() failed (result = %d)!"), result);
			goto FINALLY;
		}
	}
	


	for (NInt p_i = 1; p_i <= 1; p_i++) {
            //Philip: File Names here
			NChar *p_s1 = N_T(argv[1]);//0001_01.BMP
  	
			//printf(N_T("---------------- HERE p_subject_no = %d----------------------\n"), p_subject_no);
		    //printf(N_T("---------------- HERE p_fingerprint_no = %d----------------------\n"), p_fingerprint_no);
			
			NChar p_count_str1 [100];
			sprintf(p_count_str1, N_T("%d"), p_i);
			
			NChar p_inFileName [1000];
			strcpy (p_inFileName, p_s1);
			//strcat (p_inFileName, p_count_str1);					
			//strcat (p_inFileName,  N_T(".png"));

			//wcscpy ((wchar_t*) p_inFileName, (wchar_t*) p_s1);
			//wcscat ((wchar_t*) p_inFileName, (wchar_t*) p_count_str1);					
			//wcscat ((wchar_t*) p_inFileName, (wchar_t*) N_T(".png"));
			printf(N_T("%d p_inFileName = %s\n"), p_i, p_inFileName);

	
			NChar outFileName [1000];
			strcpy (outFileName,  p_inFileName);
			strcat (outFileName,  N_T("_featurelarge.dat"));
			//wcscpy ((wchar_t*) outFileName, (wchar_t*)  p_inFileName);
			//wcscat ((wchar_t*) outFileName, (wchar_t*) N_T("_featurelarge.dat"));
			printf(N_T("outFileName = %s\n"), outFileName);
		
			HNSubject hSubject = NULL;
			//HNFinger hFinger = NULL;	
			HNBuffer hBuffer = NULL;
			HNTemplate hTemplate = NULL;

			// create subject
			result = NSubjectCreate(&hSubject);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NSubjectCreate() failed (result = %d)!"), result);
				goto FINALLY;
			}
			printf(N_T("name_ary[p_i= %d] = %s\n"), p_i, p_inFileName);
		
			result = CreateSubject(hSubject, p_inFileName);
			if (NFailed(result))
			{
				PrintErrorMsg(N_T("CreateSubject() failed (result = %d)!"), result);
				goto FINALLY;
			}
			
			// create the template
			result = NBiometricEngineCreateTemplate(hBiometricClient, hSubject, &biometricStatus);
			if (NFailed(result))
			{
				result = PrintErrorMsgWithLastError(N_T("NBiometricEngineCreateTemplate() failed (result = %d)!"), result);
				goto FINALLY;
			}
			if (biometricStatus == nbsOk)
			{
				printf(N_T("%s template extracted\n"), standard == bsIso ? N_T("ISO") : standard == bsAnsi ? N_T("ANSI") : N_T("Proprietary"));			
				result = NSubjectGetTemplate(hSubject, &hTemplate);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("error in NSubjectGetTemplate(), error code: %d"), result);
					goto FINALLY;
				}
				/*printf(N_T("template contains:\n"));
				result = PrintNFTemplate(hTemplate);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("error in PrintNFTemplate(), error code: %d"), result); 			goto FINALLY;
				}*/
				// retrieve the template from subject
				if (standard == bsIso)
					result = NSubjectGetTemplateBufferWithFormatEx(hSubject, CBEFF_BO_ISO_IEC_JTC_1_SC_37_BIOMETRICS, CBEFF_BDBFI_ISO_IEC_JTC_1_SC_37_BIOMETRICS_FINGER_MINUTIAE_RECORD_FORMAT,
					FMR_VERSION_ISO_CURRENT, &hBuffer);
				else if (standard == bsAnsi)
					result = NSubjectGetTemplateBufferWithFormatEx(hSubject, CBEFF_BO_INCITS_TC_M1_BIOMETRICS, CBEFF_BDBFI_INCITS_TC_M1_BIOMETRICS_FINGER_MINUTIAE_U,
					FMR_VERSION_ANSI_CURRENT, &hBuffer);
				else
					result = NSubjectGetTemplateBuffer(hSubject, &hBuffer);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("NSubjectGetTemplateBuffer() failed (result = %d)!"), result);			
					goto FINALLY;
				}
				result = NFileWriteAllBytesCN(outFileName, hBuffer);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("failed to write template to file (result = %d)!"), result);			
					goto FINALLY;
				}
				printf(N_T("template saved successfully\n"));

			}
			else
			{
				// Retrieve biometric status
				result = NEnumToStringP(N_TYPE_OF(NBiometricStatus), biometricStatus, NULL, &hBiometricStatus);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("NEnumToStringP() failed (result = %d)!"), result);
					goto FINALLY;
				}
				result = NStringGetBuffer(hBiometricStatus, NULL, &szBiometricStatus);
				if (NFailed(result))
				{
					result = PrintErrorMsgWithLastError(N_T("NStringGetBuffer() failed (result = %d)!"), result);
					goto FINALLY;
				}
				printf(N_T("template extraction failed!\n"));
				printf(N_T("biometric status = %s.\n\n"), szBiometricStatus);
				result = N_E_FAILED;
				goto FINALLY;
			}
			
	}//subject for end

	result = N_OK;
	
FINALLY:
	{
		NResult result2;
		
		/*result2 = NObjectSet(NULL, &hSubject);
		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
		result2 = NObjectSet(NULL, &hFinger);
		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
		result2 = NObjectSet(NULL, &hBuffer);
		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);
		result2 = NObjectSet(NULL, &hBiometricClient);
		if (NFailed(result2)) PrintErrorMsg(N_T("NObjectSet() failed (result = %d)!"), result2);*/
		result2 = NStringSet(NULL, &hBiometricStatus);
		if (NFailed(result2)) PrintErrorMsg(N_T("NStringSet() failed (result = %d)!"), result2);
		result2 = NLicenseReleaseComponents(components);
		if (NFailed(result2)) PrintErrorMsg(N_T("NLicenseReleaseComponents() failed, result2 = %d\n"), result2);
	}

	OnExit();
	return result;
}
